<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

// Optional: Check if user is admin
// if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') { header("Location: login.php"); exit(); }

// Safely fetch stats (Compatible with older PHP versions)
$res1 = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc();
$total_orders = isset($res1['total']) ? $res1['total'] : 0;

$res2 = $conn->query("SELECT SUM(total) as revenue FROM orders")->fetch_assoc();
$total_revenue = isset($res2['revenue']) ? $res2['revenue'] : 0;

$res3 = $conn->query("SELECT COUNT(*) as today FROM orders WHERE DATE(order_date)=CURDATE()")->fetch_assoc();
$today_orders = isset($res3['today']) ? $res3['today'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f0ea; /* Soft beige background */
            margin: 0;
            padding: 0;
            color: #3b2c25;
        }

        /* HEADER */
        .header {
            background: #3E2723; /* Dark brown */
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header a {
            color: #f4f0ea;
            margin-right: 25px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: 0.3s;
        }

        .header a:hover {
            color: #d4a373; /* Warm coffee accent */
        }

        .header .theme-btn {
            background: transparent;
            border: 1px solid #f4f0ea;
            color: #f4f0ea;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            transition: 0.3s;
        }

        .header .theme-btn:hover {
            background: #f4f0ea;
            color: #3E2723;
        }

        /* MAIN CONTAINER */
        .container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 25px;
            color: #2c1f1a;
            text-align: center;
        }

        /* STATS CARDS */
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 40px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .box {
            background: #ffffff;
            padding: 25px 20px;
            border-radius: 12px;
            width: 250px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border-top: 5px solid #ccc;
            transition: transform 0.3s;
        }

        .box:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .box h3 {
            margin: 0 0 10px 0;
            font-size: 15px;
            color: #7a6b65;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .box .value {
            font-size: 32px;
            font-weight: 700;
            color: #3b2c25;
        }

        /* Specific Card Colors */
        .box:nth-child(1) { border-top-color: #2c6e73; } /* Teal */
        .box:nth-child(2) { border-top-color: #6f4e37; } /* Brown */
        .box:nth-child(3) { border-top-color: #81c784; } /* Green */

        /* TOP SELLING SECTION */
        .top-selling-section {
            background: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .top-selling-section h2 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 20px;
            color: #2c1f1a;
            border-bottom: 2px dashed #e0dcd5;
            padding-bottom: 10px;
        }

        .selling-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .selling-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 16px;
        }

        .selling-list li:last-child {
            border-bottom: none;
        }

        .sold-badge {
            background: #f4f0ea;
            color: #3b2c25;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <div>
        <a href="add_item.php"><i class="fa-solid fa-plus"></i> Add Menu</a>
        <a href="orders.php"><i class="fa-solid fa-list"></i> View Orders</a>
    </div>

    <div style="display:flex; align-items:center;">
        <a href="dashboard.php" style="margin-right: 20px;"><i class="fa-solid fa-arrow-left"></i> Back</a>
        <button class="theme-btn" onclick="toggleTheme()">Change Theme</button>
    </div>
</div>

<div class="container">
    
    <h1>Dashboard Analytics</h1>

    <!-- STATS CARDS -->
    <div class="stats">

        <div class="box">
            <h3>Total Orders</h3>
            <div class="value"><?php echo $total_orders; ?></div>
        </div>

        <div class="box">
            <h3>Total Revenue</h3>
            <div class="value">₹<?php echo number_format((float)$total_revenue, 2); ?></div>
        </div>

        <div class="box">
            <h3>Today's Orders</h3>
            <div class="value"><?php echo $today_orders; ?></div>
        </div>

    </div>

    <!-- TOP SELLING ITEMS -->
    <div class="top-selling-section">
        <h2>🏆 Top Selling Items</h2>

        <ul class="selling-list">
            <?php
            $result = $conn->query("
                SELECT item_name, SUM(quantity) as total_sold
                FROM order_items
                GROUP BY item_name
                ORDER BY total_sold DESC
                LIMIT 5
            ");

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()){
                    echo "<li>";
                    echo "<span><i class='fa-solid fa-mug-hot' style='color:#6f4e37; margin-right:10px;'></i>" . htmlspecialchars($row['item_name']) . "</span>";
                    echo "<span class='sold-badge'>" . $row['total_sold'] . " sold</span>";
                    echo "</li>";
                }
            } else {
                echo "<li style='justify-content:center; color:#777;'>No sales data available yet.</li>";
            }
            ?>
        </ul>
    </div>

</div>

<!-- THEME SCRIPT -->
<script>
function toggleTheme(){
    let body = document.body;

    if(body.classList.contains("dark")){
        body.classList.remove("dark");
        body.classList.add("medium");
        localStorage.setItem("theme","medium");

    }else if(body.classList.contains("medium")){
        body.classList.remove("medium");
        localStorage.setItem("theme","light");

    }else{
        body.classList.add("dark");
        localStorage.setItem("theme","dark");
    }
}

/* APPLY SAVED THEME ON PAGE LOAD */
window.onload = function(){
    let theme = localStorage.getItem("theme");

    if(theme === "dark"){
        document.body.classList.add("dark");
    }
    else if(theme === "medium"){
        document.body.classList.add("medium");
    }
};
</script>

</body>
</html>