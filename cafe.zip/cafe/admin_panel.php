<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<h1>Admin Panel</h1>

<a href="add_item.php">Add Menu Item</a><br>

<a href="orders.php">View Orders</a>