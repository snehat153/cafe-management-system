
<head>
    <meta charset="UTF-8">
<head>

<?php

$conn = new mysqli("localhost","root","","cafe_coffee_care");

if($conn->connect_error){
die("Connection failed");
}

?>