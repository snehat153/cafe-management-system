<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

$message = "";
$msg_type = "";

if(isset($_POST['add'])){
    $name = trim($_POST['name']);
    $price = $_POST['price'];
    $category = $_POST['category'];

    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    // Basic validation
    if (empty($name) || empty($price) || empty($category) || empty($image)) {
        $message = "Please fill in all fields and select an image.";
        $msg_type = "error";
    } else {
        // ✅ FIXED PATH: Changed from "../images/" to "images/"
        $target_dir = "images/";
        
        // Create the folder if it doesn't exist
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        // Generate a unique filename to prevent overwriting images with the same name
        $file_extension = pathinfo($image, PATHINFO_EXTENSION);
        $new_filename = time() . "_" . uniqid() . "." . $file_extension;
        $target_file = $target_dir . $new_filename;

        if (move_uploaded_file($tmp, $target_file)) {
            // Use Prepared Statement for security
            $stmt = $conn->prepare("INSERT INTO menu (item_name, price, category_id, image) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdis", $name, $price, $category, $new_filename);
            
            if ($stmt->execute()) {
                $message = "Item added successfully!";
                $msg_type = "success";
                // Reset form values after success
                $name = $price = $category = "";
            } else {
                $message = "Error adding item to database.";
                $msg_type = "error";
            }
            $stmt->close();
        } else {
            $message = "Failed to upload image. Check folder permissions.";
            $msg_type = "error";
        }
    }
}

$categories = $conn->query("SELECT * FROM categories");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Menu Item - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f0ea;
            margin: 0;
            padding: 0;
            color: #3b2c25;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #3E2723;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: 0.3s;
        }
        .back-btn:hover { background-color: #241b17; transform: translateY(-2px); }

        .form-card {
            background: #ffffff;
            width: 100%;
            max-width: 500px;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(59, 44, 37, 0.1);
            border-top: 6px solid #6f4e37;
            box-sizing: border-box;
            margin: 60px 20px;
        }

        .form-card h2 {
            text-align: center;
            color: #2c1f1a;
            margin-top: 0;
            margin-bottom: 25px;
            font-size: 24px;
        }

        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            font-weight: bold;
        }
        .alert-success { background-color: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
        .alert-error { background-color: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }

        .form-group { margin-bottom: 20px; }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
            color: #5a4b45;
        }

        .input-wrapper { position: relative; }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a89f9a;
            font-size: 16px;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 1px solid #dcdcdc;
            border-radius: 10px;
            font-size: 15px;
            outline: none;
            background-color: #fafafa;
            color: #3b2c25;
            box-sizing: border-box;
            transition: 0.3s;
        }

        .form-group select { cursor: pointer; }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #6a4e42;
            background-color: #fff;
            box-shadow: 0 0 8px rgba(106, 78, 66, 0.2);
        }

        .file-upload {
            border: 2px dashed #dcdcdc;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            background: #fafafa;
            cursor: pointer;
            transition: 0.3s;
            position: relative;
        }

        .file-upload:hover { border-color: #6f4e37; background: #fff; }

        .file-upload i {
            font-size: 30px;
            color: #6f4e37;
            margin-bottom: 10px;
            display: block;
        }

        .file-upload span { font-size: 14px; color: #777; }

        .file-upload input[type="file"] {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        .submit-btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            background: linear-gradient(to right, #2c6e73, #81c784);
            transition: 0.3s;
            margin-top: 10px;
        }

        .submit-btn:hover { transform: translateY(-2px); opacity: 0.9; }
    </style>
</head>
<body>

<a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

<div class="form-card">
    <h2>Add Menu Item</h2>

    <?php if ($message !== ""): ?>
        <div class="alert alert-<?php echo $msg_type; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label>Item Name</label>
            <div class="input-wrapper">
                <i class="fa-solid fa-mug-hot"></i>
                <input type="text" name="name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>" placeholder="e.g. Cappuccino" required>
            </div>
        </div>

        <div class="form-group">
            <label>Price (₹)</label>
            <div class="input-wrapper">
                <i class="fa-solid fa-indian-rupee-sign"></i>
                <input type="number" name="price" value="<?php echo isset($price) ? htmlspecialchars($price) : ''; ?>" placeholder="e.g. 150" required>
            </div>
        </div>

        <div class="form-group">
            <label>Category</label>
            <div class="input-wrapper">
                <i class="fa-solid fa-layer-group"></i>
                <select name="category" required>
                    <option value="">Select Category</option>
                    <?php
                    if ($categories->num_rows > 0) {
                        while($row = $categories->fetch_assoc()){
                            $selected = (isset($category) && $category == $row['id']) ? 'selected' : '';
                            echo "<option value='".$row['id']."' $selected>".htmlspecialchars($row['category_name'])."</option>";
                        }
                    }
                    ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label>Item Image</label>
            <div class="file-upload">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                <span>Click to upload or drag & drop<br><small>JPG, PNG (max 5MB)</small></span>
                <input type="file" name="image" accept="image/*" required>
            </div>
        </div>

        <button type="submit" name="add" class="submit-btn">Add Item to Menu</button>

    </form>
</div>

</body>
</html>