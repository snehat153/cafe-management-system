<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>

<?php
session_start();

$conn = new mysqli("localhost","root","","cafe_coffee_care");

if($conn->connect_error){
die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

$customer_name = $_POST['customer_name'];
$mobile = $_POST['mobile'];
$date = $_POST['date'];
$time = $_POST['time'];
$total = $_POST['total'];

/* Insert order */

$sql = "INSERT INTO orders(user_id,customer_name,mobile,order_date,order_time,total,status)
VALUES('$user_id','$customer_name','$mobile','$date','$time','$total','Pending')";

if($conn->query($sql) === TRUE){

$order_id = $conn->insert_id;  // This generates the order id

}else{

echo "Error: " . $conn->error;
exit();

}

/* Fetch cart items */

$cart = $conn->query("
SELECT cart.*,menu.item_name,menu.price
FROM cart
JOIN menu ON cart.item_id = menu.id
WHERE cart.user_id='$user_id'
");

while($row = $cart->fetch_assoc()){

$item_name = $row['item_name'];
$price = $row['price'];
$quantity = $row['quantity'];

$conn->query("INSERT INTO order_items(order_id,item_name,price,quantity)
VALUES('$order_id','$item_name','$price','$quantity')");

}

/* Clear cart */

$conn->query("DELETE FROM cart WHERE user_id='$user_id'");

/* Redirect to bill */

header("Location: bill.php?order_id=".$order_id);
exit();
?>