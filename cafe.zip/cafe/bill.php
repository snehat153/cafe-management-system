<head>
    <meta charset="UTF-8">
    <title>Invoice - Cafe Coffee Care</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5eee6;
            margin: 0;
            padding: 20px;
        }

        /* --- BACK BUTTON STYLES --- */
        .back-btn {
            position: fixed;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #6f4e37;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: 0.3s;
            z-index: 1000;
            cursor: pointer;
        }

        .back-btn:hover {
            background-color: #4b2e2e;
            transform: translateY(-2px);
        }

        /* Hide back button when printing */
        @media print {
            .back-btn { display: none; }
            .print-btn { display: none; }
            body { background: white; padding: 0; }
            .bill-container {
                box-shadow: none;
                border: 1px solid #000;
                width: 100%;
                margin: 0;
            }
        }

        /* --- BILL STYLES --- */
        .bill-container {
            width: 700px;
            margin: 0 auto 20px auto;
            background: #fffaf5;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border: 2px solid #6f4e37;
        }

        h1 {
            text-align: center;
            color: #4b2e2e;
            margin-bottom: 5px;
        }

        .sub-title {
            text-align: center;
            color: #8b5e3c;
            font-size: 14px;
            margin-bottom: 20px;
        }

        hr {
            border: none;
            border-top: 2px dashed #c8a27c;
            margin: 15px 0;
        }

        .info { line-height: 1.8; color: #3e2c23; }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th {
            background: #6f4e37;
            color: white;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        tr:hover { background: #f3e5d8; }

        .total-row td {
            background: #e6d3c3;
            font-weight: bold;
        }

        .print-btn {
            display: block;
            margin: 25px auto 0;
            padding: 10px 20px;
            background: #6f4e37;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        .print-btn:hover { background: #4b2e2e; }
    </style>
</head>

<?php
$conn = new mysqli("localhost","root","","cafe_coffee_care");

// Security: check if order_id is passed
if (!isset($_GET['order_id'])) {
    echo "<script>alert('No Order ID provided.'); history.back();</script>";
    exit();
}

$order_id = $_GET['order_id'];

// Security: Use prepared statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result();

if ($order->num_rows == 0) {
    echo "<script>alert('Order not found.'); history.back();</script>";
    exit();
}

$order_data = $order->fetch_assoc();
?>

<!-- BACK BUTTON (Uses Browser History) -->
<a href="javascript:history.back()" class="back-btn">&larr; Back</a>

<div class="bill-container">

<h1>Cafe Coffee Care ☕</h1>
<div class="sub-title">Premium Coffee Experience</div>

<hr>

<div class="info">
<b>Customer Name:</b> <?php echo htmlspecialchars($order_data['customer_name']); ?><br>
<b>Mobile:</b> <?php echo htmlspecialchars($order_data['mobile']); ?><br>
<b>Date:</b> <?php echo htmlspecialchars($order_data['order_date']); ?><br>
<b>Time:</b> <?php echo htmlspecialchars($order_data['order_time']); ?><br>
<b>Order ID:</b> #<?php echo htmlspecialchars($order_data['id']); ?><br>
</div>

<hr>

<table>

<tr>
<th>Item</th>
<th>Price</th>
<th>Quantity</th>
<th>Total</th>
</tr>

<?php

$stmt_items = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt_items->bind_param("i", $order_id);
$stmt_items->execute();
$items = $stmt_items->get_result();

$grand_total = 0;

while($row = $items->fetch_assoc()){
    $total = $row['price'] * $row['quantity'];
    $grand_total += $total;

    echo "<tr>";
    echo "<td>".htmlspecialchars($row['item_name'])."</td>";
    echo "<td>₹".$row['price']."</td>";
    echo "<td>".$row['quantity']."</td>";
    echo "<td>₹".$total."</td>";
    echo "</tr>";
}
?>

<tr class="total-row">
<td colspan="3"><b>Grand Total</b></td>
<td><b>₹<?php echo $grand_total; ?></b></td>
</tr>

</table>

<br>

<button class="print-btn" onclick="window.print()">Print Bill</button>

</div>