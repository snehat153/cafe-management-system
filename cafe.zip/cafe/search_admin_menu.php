<?php
include "db.php";

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'all';
$price = isset($_GET['price']) ? $_GET['price'] : 'all';

// 1. Build the base query
$sql = "SELECT menu.*, categories.category_name FROM menu 
        JOIN categories ON menu.category_id = categories.id WHERE 1=1";

// 2. Apply Search Filter
if ($search !== '') {
    $searchSafe = $conn->real_escape_string($search);
    $sql .= " AND menu.item_name LIKE '%$searchSafe%'";
}

// 3. Apply Category Filter
if ($category !== 'all') {
    $catSafe = $conn->real_escape_string($category);
    $sql .= " AND menu.category_id = '$catSafe'";
}

// 4. Apply Price Filter
if ($price !== 'all') {
    $priceParts = explode('-', $price);
    if (count($priceParts) == 2) {
        $min = (int)$priceParts[0];
        $max = (int)$priceParts[1];
        $sql .= " AND menu.price >= $min AND menu.price <= $max";
    }
}

$sql .= " ORDER BY categories.category_name, menu.item_name";

// 5. Execute and display
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $lastCategory = "";
    
    while($row = $result->fetch_assoc()){
        
        // Group by Category
        if ($lastCategory !== $row['category_name']) {
            if ($lastCategory !== "") {
                echo "</div>"; // Close previous grid
            }
            echo "<div class='category-title'>" . htmlspecialchars($row['category_name']) . "</div>";
            echo "<div class='menu-container'>";
            $lastCategory = $row['category_name'];
        }
        ?>
        
        <div class="menu-card">
            <div>
                <img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="item" onerror="this.src='https://via.placeholder.com/200x150?text=No+Image'">
                <h3><?php echo htmlspecialchars($row['item_name']); ?></h3>
                <div class="price">₹<?php echo $row['price']; ?></div>
            </div>
            
            <div class="card-actions">
                <a href="edit_item.php?id=<?php echo $row['id']; ?>" class="btn btn-edit"><i class="fa-solid fa-pen"></i> Edit</a>
                <a href="delete_item.php?id=<?php echo $row['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa-solid fa-trash"></i> Delete</a>
            </div>
        </div>

        <?php
    }
    echo "</div>"; // Close final grid
} else {
    echo "<h3 style='text-align:center; width:100%; color:#777;'>No items found matching your filters.</h3>";
}
?>