<?php
include "db.php";
include "navbar.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cafe Coffee Care Menu</title>
    <style>
        .menu-container {
            display: grid !important;
            grid-template-columns: repeat(5, 1fr) !important; /* Changed to 5 columns */
            gap: 15px; /* Slightly reduced gap to fit 5 items */
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        .card {
            border: 1px solid #ddd;
            padding: 10px; /* Slightly reduced padding */
            text-align: center;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .card img {
            width: 100%;
            height: 120px; /* Reduced height slightly for 5-column layout */
            object-fit: cover;
            border-radius: 5px;
        }
        
        .card h3 {
            font-size: 16px; /* Adjusted text size */
            margin: 10px 0 5px 0;
        }

        /* --- Filter Bar Styles --- */
        .filter-bar {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
            margin: 20px;
            flex-wrap: wrap;
        }

        .filter-bar input, 
        .filter-bar select, 
        .filter-bar button {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
            outline: none;
        }

        .filter-bar input[type="text"] {
            width: 250px;
        }

        .filter-bar button {
            background-color: #3b2c25;
            color: white;
            cursor: pointer;
            border: none;
            transition: 0.3s;
        }

        .filter-bar button:hover {
            background-color: #241b17;
        }
        
        /* Make it responsive for smaller screens */
        @media (max-width: 1200px) {
            .menu-container { grid-template-columns: repeat(4, 1fr) !important; }
        }
        @media (max-width: 900px) {
            .menu-container { grid-template-columns: repeat(3, 1fr) !important; }
        }
        @media (max-width: 600px) {
            .menu-container { grid-template-columns: repeat(2, 1fr) !important; }
        }
    </style>
    
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header style="text-align:center; font-size:28px; margin:20px;">
    Cafe Coffee Care Menu
</header>

<!-- 🔍 FILTER BAR (Search, Category, Price, Reset) -->
<div class="filter-bar">
    
    <!-- Search -->
    <input type="text" id="search" placeholder="Search menu item...">

    <!-- Category Filter -->
    <select id="category-filter">
        <option value="all">All Categories</option>
        <?php
        $cats = $conn->query("SELECT * FROM categories");
        while($cat = $cats->fetch_assoc()){
            echo "<option value='".$cat['id']."'>".$cat['category_name']."</option>";
        }
        ?>
    </select>

    <!-- Price Filter -->
    <select id="price-filter">
        <option value="all">Any Price</option>
        <option value="0-100">Under ₹100</option>
        <option value="100-200">₹100 - ₹200</option>
        <option value="200-500">₹200 - ₹500</option>
        <option value="500-99999">Above ₹500</option>
    </select>

    <!-- Reset Button -->
    <button id="reset-btn">Reset Filters</button>

</div>

<!-- 🔥 MENU OUTPUT -->
<div id="menu-data">

<?php

$categories=$conn->query("SELECT * FROM categories");

while($cat=$categories->fetch_assoc()){

echo "<h2>".$cat['category_name']."</h2>";

echo "<div class='menu-container'>";

$result=$conn->query("SELECT * FROM menu WHERE category_id=".$cat['id']);

while($row=$result->fetch_assoc()){
?>

<div class="card">

<img src="images/<?php echo $row['image']; ?>"><br>

<h3><?php echo $row['item_name']; ?></h3>

<p>₹<?php echo $row['price']; ?></p>

<button onclick="addToCart(<?php echo $row['id']; ?>)">
Add to Cart
</button>

</div>

<?php
}

echo "</div>";
}
?>

</div>

<!-- 🔥 AJAX SCRIPT -->
<script>
    // Function to fetch menu data based on all filters
    function fetchMenu() {
        let search = document.getElementById("search").value;
        let category = document.getElementById("category-filter").value;
        let price = document.getElementById("price-filter").value;

        let xhr = new XMLHttpRequest();
        // Pass all three parameters to the backend
        xhr.open("GET", "search_menu.php?search=" + encodeURIComponent(search) + "&category=" + category + "&price=" + price, true);

        xhr.onload = function(){
            if(this.status == 200){
                document.getElementById("menu-data").innerHTML = this.responseText;
            }
        };

        xhr.send();
    }

    // Add event listeners to all filters
    document.getElementById("search").addEventListener("keyup", fetchMenu);
    document.getElementById("category-filter").addEventListener("change", fetchMenu);
    document.getElementById("price-filter").addEventListener("change", fetchMenu);

    // Reset Button Logic
    document.getElementById("reset-btn").addEventListener("click", function(){
        document.getElementById("search").value = "";
        document.getElementById("category-filter").value = "all";
        document.getElementById("price-filter").value = "all";
        fetchMenu(); // Fetch the original menu again
    });

    // Add to Cart function
    function addToCart(id){
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "add_to_cart.php?id=" + id, true);

        xhr.onload = function(){
            if(this.status == 200){
                alert("Item added to cart ✅"); 
            }
        };

        xhr.send();
    }
</script>

</body>
</html>