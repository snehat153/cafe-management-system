<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

$conn = new mysqli("localhost","root","","cafe_coffee_care");

$orders = $conn->query("SELECT * FROM orders ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f0ea; /* Soft beige */
            margin: 0;
            padding: 0;
            color: #3b2c25;
        }

        /* --- BACK BUTTON --- */
        .back-btn {
            position: fixed;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #3E2723;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: 0.3s;
            z-index: 1000;
        }

        .back-btn:hover {
            background-color: #241b17;
            transform: translateY(-2px);
        }

        /* --- MAIN CONTAINER --- */
        .container {
            max-width: 1000px;
            margin: 80px auto 40px auto; /* Pushed down to clear fixed back button */
            padding: 0 20px;
        }

        h1 {
            font-size: 28px;
            color: #2c1f1a;
            margin-bottom: 20px;
            text-align: center;
        }

        /* --- SEARCH BAR --- */
        .search-container {
            text-align: center;
            margin-bottom: 30px;
        }

        .search-container input {
            padding: 12px 20px;
            width: 100%;
            max-width: 400px;
            border: 1px solid #dcdcdc;
            border-radius: 25px;
            font-size: 15px;
            outline: none;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: 0.3s;
        }

        .search-container input:focus {
            border-color: #6f4e37;
            box-shadow: 0 0 8px rgba(111, 78, 55, 0.2);
        }

        /* --- ORDER CARDS --- */
        .order-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            border-left: 6px solid #6f4e37; /* Brown accent */
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .order-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(59, 44, 37, 0.1);
        }

        .order-info {
            line-height: 1.6;
        }

        .order-id {
            font-size: 18px;
            font-weight: bold;
            color: #3b2c25;
        }

        .order-actions {
            display: flex;
            gap: 10px;
        }

        .view-btn, .status-btn {
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            transition: 0.3s;
        }

        .view-btn {
            background-color: #f4f0ea;
            color: #3b2c25;
            border: 1px solid #dcdcdc;
        }

        .view-btn:hover {
            background-color: #e0dcd5;
        }

        .status-btn {
            background-color: #2c6e73; /* Teal */
            color: white;
            border: 1px solid #2c6e73;
        }

        .status-btn:hover {
            background-color: #1f4f53;
        }

        /* Hidden class for filtering */
        .hidden {
            display: none !important;
        }
    </style>
</head>
<body>

<!-- Back Button (Now goes directly to Dashboard) -->
<a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

<div class="container">
    <h1>Orders Management</h1>

    <!-- Search Filter -->
    <div class="search-container">
        <input type="text" id="order-search" placeholder="Search by Order ID (e.g. 101)">
    </div>

    <div id="orders-list">
        <?php
        if ($orders->num_rows > 0) {
            while($row = $orders->fetch_assoc()) {
                ?>
                <div class="order-card" data-id="<?php echo $row['id']; ?>">
                    <div class="order-info">
                        <span class="order-id">Order ID: #<?php echo $row['id']; ?></span><br>
                        Customer: <?php echo htmlspecialchars($row['customer_name']); ?>
                    </div>
                    <div class="order-actions">
                        <a class="view-btn" href="bill.php?order_id=<?php echo $row['id']; ?>">View Bill</a>
                        <a class="status-btn" href="update_status.php?id=<?php echo $row['id']; ?>">Update Status</a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p style='text-align:center; color:#777;'>No orders found in the system.</p>";
        }
        ?>
    </div>
</div>

<!-- JavaScript for ID Filter -->
<script>
    document.getElementById("order-search").addEventListener("keyup", function() {
        let searchValue = this.value.toLowerCase().trim();
        let cards = document.querySelectorAll(".order-card");

        cards.forEach(function(card) {
            // Get the order ID from the data-id attribute
            let orderId = card.getAttribute("data-id").toLowerCase();
            
            // If the typed value matches the ID, show it. Otherwise, hide it.
            if (orderId.includes(searchValue)) {
                card.classList.remove("hidden");
            } else {
                card.classList.add("hidden");
            }
        });
    });
</script>

</body>
</html>