<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

// Check if ID exists in URL
if (!isset($_GET['id'])) {
    echo "<script>alert('No Order ID provided.'); window.location.href='orders.php';</script>";
    exit();
}

$id = $_GET['id'];

// Handle Form Submit
if (isset($_POST['update'])) {
    $status = $_POST['status'];

    // Use Prepared Statement for security
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $id);

    if ($stmt->execute()) {
        echo "<script>
                alert('Order status updated successfully!');
                window.location.href = 'orders.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Error updating status. Please try again.');</script>";
    }
    $stmt->close();
}

// Fetch current order details (to show existing status)
$stmt_fetch = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt_fetch->bind_param("i", $id);
$stmt_fetch->execute();
$result = $stmt_fetch->get_result();

if ($result->num_rows == 0) {
    echo "<script>alert('Order not found.'); window.location.href='orders.php';</script>";
    exit();
}

$order = $result->fetch_assoc();
$current_status = $order['status'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order Status - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f0ea; /* Soft beige */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #3b2c25;
        }

        /* BACK BUTTON */
        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #3E2723; /* Dark brown */
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: 0.3s;
        }

        .back-btn:hover {
            background-color: #241b17;
            transform: translateY(-2px);
        }

        /* MAIN CARD */
        .status-card {
            background: #ffffff;
            width: 100%;
            max-width: 450px;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(59, 44, 37, 0.1);
            border-top: 6px solid #6f4e37;
            text-align: center;
        }

        .status-card h2 {
            margin-top: 0;
            color: #2c1f1a;
            font-size: 24px;
            margin-bottom: 10px;
        }

        .order-id {
            color: #777;
            font-size: 15px;
            margin-bottom: 30px;
        }

        .order-id span {
            color: #6f4e37;
            font-weight: bold;
        }

        .current-status-badge {
            display: inline-block;
            background: #f4f0ea;
            color: #3b2c25;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 25px;
        }

        /* FORM GROUP */
        .form-group {
            text-align: left;
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-size: 14px;
            font-weight: 600;
            color: #5a4b45;
        }

        .form-group select {
            width: 100%;
            padding: 15px;
            border: 1px solid #dcdcdc;
            border-radius: 10px;
            font-size: 16px;
            outline: none;
            background-color: #fafafa;
            color: #3b2c25;
            cursor: pointer;
            transition: 0.3s;
            box-sizing: border-box;
        }

        .form-group select:focus {
            border-color: #6a4e42;
            box-shadow: 0 0 5px rgba(106, 78, 66, 0.2);
            background-color: #fff;
        }

        /* SUBMIT BUTTON */
        .update-btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            background: linear-gradient(to right, #2c6e73, #81c784); /* Teal to Green */
            transition: 0.3s;
        }

        .update-btn:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }
    </style>
</head>
<body>

<!-- Back Button -->
<a href="orders.php" class="back-btn">&larr; Back to Orders</a>

<div class="status-card">
    <h2>Update Order Status</h2>
    
    <div class="order-id">Order ID: <span>#<?php echo htmlspecialchars($order['id']); ?></span></div>
    
    <div class="current-status-badge">Current Status: <?php echo htmlspecialchars($current_status); ?></div>

    <form method="post">
        
        <div class="form-group">
            <label for="status">Select New Status</label>
            <select name="status" id="status" required>
                <option value="Pending" <?php if($current_status == 'Pending') echo 'selected'; ?>>Pending</option>
                <option value="Preparing" <?php if($current_status == 'Preparing') echo 'selected'; ?>>Preparing</option>
                <option value="Ready" <?php if($current_status == 'Ready') echo 'selected'; ?>>Ready</option>
                <option value="Completed" <?php if($current_status == 'Completed') echo 'selected'; ?>>Completed</option>
            </select>
        </div>

        <button type="submit" name="update" class="update-btn">Update Status</button>

    </form>
</div>

</body>
</html>