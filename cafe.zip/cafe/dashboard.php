<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

// Fetch Stats (Compatible with older PHP versions)
$res1 = $conn->query("SELECT COUNT(*) as total FROM orders")->fetch_assoc();
$total_orders = isset($res1['total']) ? $res1['total'] : 0;

$res2 = $conn->query("SELECT SUM(total) as revenue FROM orders")->fetch_assoc();
$total_revenue = isset($res2['revenue']) ? $res2['revenue'] : 0;

$res3 = $conn->query("SELECT COUNT(*) as today FROM orders WHERE DATE(order_date)=CURDATE()")->fetch_assoc();
$today_orders = isset($res3['today']) ? $res3['today'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Menu Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        /* ... (Keep all the CSS from your original dashboard.php exactly the same) ... */
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f0ea; margin: 0; padding: 0; color: #3b2c25; }
        .header { background: #3E2723; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header a { color: #f4f0ea; margin-right: 25px; text-decoration: none; font-weight: 600; font-size: 14px; transition: 0.3s; }
        .header a:hover { color: #d4a373; }
        .header .theme-btn { background: transparent; border: 1px solid #f4f0ea; color: #f4f0ea; padding: 8px 15px; border-radius: 20px; cursor: pointer; font-size: 13px; transition: 0.3s; margin-left: 20px; }
        .header .theme-btn:hover { background: #f4f0ea; color: #3E2723; }
        .logout-btn { background: #c62828; color: white !important; border: 1px solid #c62828; padding: 8px 15px; border-radius: 20px; font-size: 13px; font-weight: bold; text-decoration: none; margin-left: 15px; transition: 0.3s; display: inline-block; }
        .logout-btn:hover { background: #b71c1c; color: white !important; border-color: #b71c1c; }
        .container { max-width: 1400px; margin: 40px auto; padding: 0 20px; }
        .page-title { font-size: 28px; margin-bottom: 10px; color: #2c1f1a; }
        .divider { border: none; border-top: 2px dashed #d4a373; margin: 20px 0 30px 0; }
        .filter-bar { display: flex; justify-content: center; align-items: center; gap: 15px; margin-bottom: 30px; flex-wrap: wrap; background: #ffffff; padding: 15px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .filter-bar input, .filter-bar select, .filter-bar button { padding: 10px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; outline: none; }
        .filter-bar input[type="text"] { width: 250px; }
        .filter-bar button { background-color: #3E2723; color: white; cursor: pointer; border: none; transition: 0.3s; font-weight: bold; }
        .filter-bar button:hover { background-color: #241b17; }
        .menu-container { display: grid !important; grid-template-columns: repeat(5, 1fr) !important; gap: 20px; width: 100%; box-sizing: border-box; margin-bottom: 40px; }
        .menu-card { background: #ffffff; border: 1px solid #e0dcd5; border-radius: 12px; padding: 15px; text-align: center; box-shadow: 0 4px 10px rgba(0,0,0,0.03); transition: transform 0.3s, box-shadow 0.3s; display: flex; flex-direction: column; justify-content: space-between; }
        .menu-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(59, 44, 37, 0.1); }
        .menu-card img { width: 100%; height: 130px; object-fit: cover; border-radius: 8px; margin-bottom: 15px; background-color: #f9f9f9; }
        .menu-card h3 { margin: 0 0 10px 0; font-size: 16px; color: #3b2c25; }
        .menu-card .price { font-size: 15px; font-weight: bold; color: #6f4e37; margin-bottom: 15px; }
        .card-actions { display: flex; justify-content: space-between; gap: 10px; }
        .btn { flex: 1; padding: 8px 0; text-align: center; text-decoration: none; border-radius: 5px; font-size: 13px; font-weight: bold; transition: 0.3s; }
        .btn-edit { background-color: #e3f2fd; color: #1565c0; border: 1px solid #bbdefb; }
        .btn-edit:hover { background-color: #1565c0; color: white; }
        .btn-delete { background-color: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }
        .btn-delete:hover { background-color: #c62828; color: white; }
        @media (max-width: 1200px) { .menu-container { grid-template-columns: repeat(4, 1fr) !important; } }
        @media (max-width: 900px) { .menu-container { grid-template-columns: repeat(3, 1fr) !important; } }
        @media (max-width: 600px) { .menu-container { grid-template-columns: repeat(2, 1fr) !important; } }
        .category-title { font-size: 22px; color: #3b2c25; margin-top: 30px; margin-bottom: 10px; border-bottom: 2px solid #d4a373; display: inline-block; padding-bottom: 5px; }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <div>
        <a href="add_item.php"><i class="fa-solid fa-plus"></i> Add Menu</a>
        <a href="add_category.php"><i class="fa-solid fa-folder-plus"></i> Add Category</a> <!-- NEW LINK ADDED -->
        <a href="orders.php"><i class="fa-solid fa-list"></i> View Orders</a>
    </div>

    <div style="display:flex; align-items:center;">
        <a href="dash.php" style="margin-right: 0;"><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
        <button class="theme-btn" onclick="toggleTheme()">Change Theme</button>
        <a href="logout.php" class="logout-btn"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </div>
</div>

<div class="container">
    <h1 class="page-title">Menu Items Management</h1>
    <hr class="divider">

    <!-- 🔍 FILTER BAR -->
    <div class="filter-bar">
        <input type="text" id="search" placeholder="Search menu item...">
        <select id="category-filter">
            <option value="all">All Categories</option>
            <?php
            $cats = $conn->query("SELECT * FROM categories");
            while($cat = $cats->fetch_assoc()){
                echo "<option value='".$cat['id']."'>".$cat['category_name']."</option>";
            }
            ?>
        </select>
        <select id="price-filter">
            <option value="all">Any Price</option>
            <option value="0-100">Under ₹100</option>
            <option value="100-200">₹100 - ₹200</option>
            <option value="200-500">₹200 - ₹500</option>
            <option value="500-99999">Above ₹500</option>
        </select>
        <button id="reset-btn">Reset Filters</button>
    </div>

    <!-- 🔥 MENU OUTPUT -->
    <div id="menu-data">
    <?php
    $categories = $conn->query("SELECT * FROM categories");
    while($cat = $categories->fetch_assoc()){
        echo "<div class='category-title'>" . htmlspecialchars($cat['category_name']) . "</div>";
        echo "<div class='menu-container'>";
        $result = $conn->query("SELECT * FROM menu WHERE category_id=".$cat['id']);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()){
                ?>
                <div class="menu-card">
                    <div>
                        <img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="item" onerror="this.src='https://via.placeholder.com/200x150?text=No+Image'">
                        <h3><?php echo htmlspecialchars($row['item_name']); ?></h3>
                        <div class="price">₹<?php echo $row['price']; ?></div>
                    </div>
                    <div class="card-actions">
                        <a href="edit_item.php?id=<?php echo $row['id']; ?>" class="btn btn-edit"><i class="fa-solid fa-pen"></i> Edit</a>
                        <a href="delete_item.php?id=<?php echo $row['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa-solid fa-trash"></i> Delete</a>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p style='color:#777;'>No items in this category.</p>";
        }
        echo "</div>";
    }
    ?>
    </div>
</div>

<!-- THEME SCRIPT -->
<script>
function toggleTheme(){
    let body = document.body;
    if(body.classList.contains("dark")){
        body.classList.remove("dark");
        body.classList.add("medium");
        localStorage.setItem("theme","medium");
    }else if(body.classList.contains("medium")){
        body.classList.remove("medium");
        localStorage.setItem("theme","light");
    }else{
        body.classList.add("dark");
        localStorage.setItem("theme","dark");
    }
}
window.onload = function(){
    let theme = localStorage.getItem("theme");
    if(theme === "dark"){ document.body.classList.add("dark"); }
    else if(theme === "medium"){ document.body.classList.add("medium"); }
};
</script>

<!-- 🔥 AJAX SCRIPT FOR FILTERS -->
<script>
    function fetchMenu() {
        let search = document.getElementById("search").value;
        let category = document.getElementById("category-filter").value;
        let price = document.getElementById("price-filter").value;
        let xhr = new XMLHttpRequest();
        xhr.open("GET", "search_admin_menu.php?search=" + encodeURIComponent(search) + "&category=" + category + "&price=" + price, true);
        xhr.onload = function(){
            if(this.status == 200){
                document.getElementById("menu-data").innerHTML = this.responseText;
            }
        };
        xhr.send();
    }
    document.getElementById("search").addEventListener("keyup", fetchMenu);
    document.getElementById("category-filter").addEventListener("change", fetchMenu);
    document.getElementById("price-filter").addEventListener("change", fetchMenu);
    document.getElementById("reset-btn").addEventListener("click", function(){
        document.getElementById("search").value = "";
        document.getElementById("category-filter").value = "all";
        document.getElementById("price-filter").value = "all";
        fetchMenu();
    });
</script>

</body>
</html>