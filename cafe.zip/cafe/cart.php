<?php
session_start();

include "db.php";
include "navbar.php";

// Check if the user is logged in. 
if (!isset($_SESSION['user_id'])) {
    // Show the "Login First" message instead of a popup
    echo "
    <div style='display: flex; flex-direction: column; justify-content: center; align-items: center; height: 60vh; font-family: sans-serif;'>
        <h2 style='color: #3b2c25; margin-bottom: 10px;'>Login First</h2>
        <p style='color: #777; margin-bottom: 20px;'>You need to be logged in to view your cart.</p>
        <a href='login.php' style='padding: 12px 30px; background-color: #3E2723; color: white; text-decoration: none; border-radius: 25px; font-weight: bold;'>Go to Login</a>
    </div>
    ";
    
    // Stop the rest of the page from loading
    exit(); 
}

// If logged in, proceed to show the cart
$user_id = $_SESSION['user_id'];

// Using Prepared Statement for security
$stmt = $conn->prepare("SELECT menu.item_name, menu.price, cart.quantity, cart.id, menu.id as item_id
                        FROM cart
                        JOIN menu ON cart.item_id = menu.id
                        WHERE cart.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$total = 0;

echo "<div style='padding: 20px; font-family: sans-serif; max-width: 800px; margin: 0 auto;'>";
echo "<h2 style='color: #3b2c25;'>Your Cart</h2>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()){

        echo "<div style='border:1px solid #ddd; padding:15px; margin:10px 0; border-radius:10px; background:#fff;'>";

        echo "<h3 style='margin:0 0 10px 0; color:#3b2c25;'>" . $row['item_name'] . "</h3>";
        echo "<p style='margin:0;'>Price: ₹" . $row['price'] . "</p>";

        echo "
        <div style='margin: 10px 0; display: flex; align-items: center; gap: 10px;'>
            <a href='update_cart.php?action=minus&id=".$row['item_id']."' style='text-decoration:none; font-size:18px; background:#eee; padding:2px 10px; border-radius:5px; color:black;'>-</a>
            <span style='font-weight:bold;'>" . $row['quantity'] . "</span>
            <a href='update_cart.php?action=plus&id=".$row['item_id']."' style='text-decoration:none; font-size:18px; background:#eee; padding:2px 10px; border-radius:5px; color:black;'>+</a>
        </div>
        ";

        $subtotal = $row['price'] * $row['quantity'];
        echo "<p style='margin:0; font-weight:bold;'>Subtotal: ₹" . $subtotal . "</p>";

        echo "<a href='remove_cart.php?id=".$row['id']."' style='color:red; text-decoration:none; font-size:14px; display:inline-block; margin-top:10px;'>Remove</a>";

        echo "</div>";

        $total += $subtotal;
    }

    echo "<h3 style='text-align:right; color:#3b2c25; margin-top:20px;'>Total: ₹" . $total . "</h3>";
    echo "<div style='text-align:right;'>
            <a href='checkout.php'>
                <button style='padding:12px 30px; background:#3E2723; color:white; border:none; border-radius:25px; font-size:16px; cursor:pointer;'>Checkout</button>
            </a>
          </div>";

} else {
    echo "<p style='text-align:center; color:#777; margin-top:50px;'>Your cart is empty.</p>";
}

echo "</div>";

$stmt->close();
?>