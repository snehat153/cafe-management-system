<?php
session_start();

// Use your existing database connection logic or include db.php
$conn = new mysqli("localhost", "root", "", "cafe_coffee_care");

$errors = [];
$success = "";
$email = "";

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    
    $email = trim($_POST['email'] ? $_POST['email'] : '');
    $password = $_POST['password'] ? $_POST['password'] : '';

    // Validation
    if ($email === '') {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if ($password === '') {
        $errors[] = "Password is required.";
    }

    // Only proceed if no validation errors
    if (empty($errors)) {
        
        // Use Prepared Statement to prevent SQL Injection
        $stmt = $conn->prepare("SELECT id, role, password FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Verify the hashed password
            if (password_verify($password, $user['password'])) {
                
                // Set sessions
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];

                // Redirect based on role
                if ($user['role'] == "admin") {
                    header("Location: dashboard.php");
                } else {
                    header("Location: menu.php");
                }
                exit();
                
            } else {
                // DEBUGGING: Check if the database actually contains a hash or plain text
                if (strlen($user['password']) < 60) {
                    $errors[] = "Invalid password. (Warning: Your database password is not hashed! Please update it).";
                } else {
                    $errors[] = "Invalid password. Please try again.";
                }
            }
        } else {
            $errors[] = "Invalid email or account does not exist.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gardenia</title>
    <link rel="stylesheet" href="style.css">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        /* Background styling */
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #e8e4db; /* Soft beige background */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        /* Top Text */
        .page-title {
            position: absolute;
            top: 30px;
            font-size: 20px;
            font-weight: 600;
            color: #3b2c25; /* Dark brown */
            letter-spacing: 1px;
        }

        /* Container - White Box with shadow */
        .container {
            display: flex;
            width: 900px;
            height: 550px;
            background-color: #ffffff; /* White box */
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(59, 44, 37, 0.15); /* Brownish shadow */
            overflow: hidden;
            position: relative;
        }

        /* Back button positioned top-left */
        #login.back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: rgba(59, 44, 37, 0.7); /* Brown */
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            z-index: 1000;
            transition: 0.3s;
        }
        #login.back-btn:hover {
            background-color: #3b2c25;
        }

        /* LEFT SIDE: Text and Form */
        .left-side {
            width: 50%;
            padding: 50px 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-sizing: border-box;
            background-color: #ffffff;
            z-index: 2;
        }

        .left-side h2 {
            font-size: 28px;
            color: #3b2c25; /* Dark brown */
            margin-bottom: 20px; /* Adjusted margin */
            margin-top: 0;
            font-weight: 700;
        }

        /* Form Groups */
        .form-group {
            position: relative;
            margin-bottom: 20px;
        }

        .form-group i.field-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a89f9a;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px 12px 40px; /* Space for left icon */
            border: 1px solid #dcdcdc;
            border-radius: 25px; /* Rounded inputs like the template */
            outline: none;
            font-size: 14px;
            background-color: #ffffff;
            box-sizing: border-box;
            transition: 0.3s;
            color: #3b2c25;
        }

        .form-group input:focus {
            border-color: #6a4e42; /* Brown focus */
            box-shadow: 0 0 5px rgba(106, 78, 66, 0.2);
        }

        /* Eye Icon (Right Side) */
        .form-group .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a89f9a;
            cursor: pointer;
            font-size: 14px;
            z-index: 10;
        }

        /* Submit Button */
        button[name="login"] {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 25px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            background-color: #3b2c25; /* Dark Brown Button */
            margin-top: 10px;
            transition: 0.3s;
        }

        button[name="login"]:hover {
            background-color: #241b17;
        }

        /* Bottom Register Link */
        .register-link {
            text-align: center;
            font-size: 13px;
            color: #7a6b65;
            margin-top: 25px;
        }

        .register-link a {
            color: #3b2c25;
            font-weight: bold;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        /* RIGHT SIDE: Image */
        .right-side {
            width: 50%;
            background-image: url('https://i.pinimg.com/736x/4c/31/8b/4c318bc1f972b3d6f54e50f94bfa7142.jpg'); 
            background-size: cover;
            background-position: center;
            border-top-left-radius: 150px; /* Creates that curved overlap effect */
            border-bottom-left-radius: 150px;
            z-index: 1;
        }
        
        /* Add a brown tint overlay to the image to match the theme */
        .right-side::before {
            content: '';
            position: absolute;
            top: 0; right: 0; bottom: 0; left: 50%;
            background: linear-gradient(to right, rgba(255,255,255,1) 0%, rgba(59,44,37,0.1) 50%, rgba(59,44,37,0.3) 100%);
            border-top-left-radius: 150px;
            border-bottom-left-radius: 150px;
        }
    </style>
</head>
<body>

    <div class="page-title">Log In / Sign up</div>

    <!-- Back button top-left, same ID as Login button -->
    <a href="javascript:history.back()" id="login" class="back-btn">&larr; Back</a>

    <div class="container">
        <!-- Left Side: Form -->
        <div class="left-side">
            <h2>Welcome Back</h2>
        
            <form method="POST">
                
                <div class="form-group">
                    <i class="fa-regular fa-envelope field-icon"></i>
                    <input type="email" name="email" required placeholder="Email Address"
                           value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>">
                </div>

                <div class="form-group">
                    <i class="fa-solid fa-lock field-icon"></i>
                    <input type="password" name="password" id="password" required placeholder="Password">
                    <!-- Eye Toggle Button -->
                    <i class="fa-regular fa-eye-slash toggle-password" onclick="togglePassword()"></i>
                </div>

                <button type="submit" name="login" id="login">Log In</button>

            </form>

            <div class="register-link">
                Not registered? <a href="register.php">Register yourself first</a>
            </div>
        </div>

        <!-- Right Side: Image -->
        <div class="right-side"></div>
    </div>

    <!-- JavaScript for Eye Button and Popups -->
    <script>
        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var icon = document.querySelector(".toggle-password");
            
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            } else {
                passwordInput.type = "password";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            }
        }

        // PHP Error Popups
        <?php if (!empty($errors)): ?>
            alert(<?php echo json_encode(implode("\n", $errors)); ?>);
        <?php endif; ?>
    </script>

</body>
</html>