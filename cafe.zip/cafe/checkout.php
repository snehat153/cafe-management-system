<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    include "navbar.php";
    echo "
    <div style='display: flex; flex-direction: column; justify-content: center; align-items: center; height: 60vh; font-family: sans-serif;'>
        <h2 style='color: #3b2c25; margin-bottom: 10px;'>Login First</h2>
        <p style='color: #777; margin-bottom: 20px;'>You need to be logged in to checkout.</p>
        <a href='login.php' style='padding: 12px 30px; background-color: #3E2723; color: white; text-decoration: none; border-radius: 25px; font-weight: bold;'>Go to Login</a>
    </div>
    ";
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch cart total using Prepared Statement
$stmt = $conn->prepare("
    SELECT cart.quantity, menu.price
    FROM cart
    JOIN menu ON cart.item_id = menu.id
    WHERE cart.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$total = 0;
while($row = $result->fetch_assoc()){
    $total += $row['price'] * $row['quantity'];
}
$stmt->close();

// If cart is empty, don't let them checkout
if ($total == 0) {
    include "navbar.php";
    echo "
    <div style='display: flex; flex-direction: column; justify-content: center; align-items: center; height: 60vh; font-family: sans-serif;'>
        <h2 style='color: #3b2c25; margin-bottom: 10px;'>Your Cart is Empty</h2>
        <p style='color: #777; margin-bottom: 20px;'>Please add some items before checking out.</p>
        <a href='menu.php' style='padding: 12px 30px; background-color: #3E2723; color: white; text-decoration: none; border-radius: 25px; font-weight: bold;'>Go to Menu</a>
    </div>
    ";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    
    <style>
        body {
            background-color: #e8e4db; /* Soft beige */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }

        .checkout-wrapper {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 20px;
            gap: 30px;
            flex-wrap: wrap;
        }

        .checkout-card {
            background: #ffffff;
            width: 100%;
            max-width: 500px;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(59, 44, 37, 0.1);
            box-sizing: border-box;
        }

        .checkout-card h2 {
            text-align: center;
            color: #3b2c25;
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 28px;
        }

        .total-box {
            background-color: #f4f0ea;
            border: 1px solid #e0dcd5;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
        }

        .total-box h3 {
            margin: 0;
            color: #3b2c25;
            font-size: 22px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #5a4b45;
            font-size: 14px;
            font-weight: 600;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #dcdcdc;
            border-radius: 10px;
            font-size: 15px;
            outline: none;
            box-sizing: border-box;
            transition: 0.3s;
            color: #3b2c25;
            background-color: #fafafa;
        }

        .form-group input:focus {
            border-color: #6a4e42;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(106, 78, 66, 0.2);
        }

        .row {
            display: flex;
            gap: 15px;
        }

        .row .form-group {
            flex: 1;
        }

        .place-order-btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 30px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            background: linear-gradient(to right, #2c6e73, #81c784); /* Keeping your green/teal theme for action */
            margin-top: 10px;
            transition: 0.3s;
        }

        .place-order-btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<?php include "navbar.php"; ?>

<div class="checkout-wrapper">
    <div class="checkout-card">
        <h2>Checkout</h2>

        <div class="total-box">
            <h3>Total Amount: ₹<?php echo $total; ?></h3>
        </div>

        <form method="POST" action="place_order.php">

            <input type="hidden" name="total" value="<?php echo $total; ?>">

            <div class="form-group">
                <label>Customer Name</label>
                <input type="text" name="customer_name" required placeholder="Enter your full name">
            </div>

            <div class="form-group">
                <label>Mobile Number</label>
                <input type="text" name="mobile" required placeholder="Enter your mobile number">
            </div>

            <div class="row">
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="date" id="date" required>
                </div>
                <div class="form-group">
                    <label>Time</label>
                    <input type="time" name="time" id="time" required>
                </div>
            </div>

            <button type="submit" class="place-order-btn">Place Order</button>

        </form>
    </div>
</div>

<script>
window.onload = function(){
    let now = new Date();

    // 👉 FORMAT DATE (YYYY-MM-DD)
    let year = now.getFullYear();
    let month = String(now.getMonth() + 1).padStart(2, '0');
    let day = String(now.getDate()).padStart(2, '0');
    let today = year + "-" + month + "-" + day;

    // 👉 FORMAT TIME (HH:MM)
    let hours = String(now.getHours()).padStart(2, '0');
    let minutes = String(now.getMinutes()).padStart(2, '0');
    let currentTime = hours + ":" + minutes;

    // 👉 SET VALUES
    document.getElementById("date").value = today;
    document.getElementById("time").value = currentTime;
};
</script>

</body>
</html>