<?php
// Start session to check if user is logged in
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>

<div style="background:#3E2723;padding:15px;color:white">

<a href="index.php" style="color:white;margin-right:20px;">Home</a>
<a href="menu.php" style="color:white;margin-right:20px;">Menu</a>
<a href="cart.php" style="color:white;margin-right:20px;">Cart</a>
<a href="order_history.php" style="color:white;margin-right:20px;">Orders</a>
<a href="order_status.php" style="color:white;margin-right:20px;">Track Order</a>

<!-- PHP Logic for Login/Register/Logout -->
<?php if (isset($_SESSION['user_id'])): ?>
    <!-- Show ONLY when logged in -->
    <a href="logout.php" style="color:white;margin-right:20px;">Logout</a>
<?php else: ?>
    <!-- Show ONLY when NOT logged in -->
    <a href="login.php" style="color:white;margin-right:20px;">Login</a>
    <a href="register.php" style="color:white;margin-right:20px;">Register</a>
<?php endif; ?>

<button onclick="toggleTheme()">Change Theme</button>

</div>

<script>
function toggleTheme(){
    let body = document.body;

    if(body.classList.contains("dark")){
        body.classList.remove("dark");
        body.classList.add("medium");
        localStorage.setItem("theme","medium");

    }else if(body.classList.contains("medium")){
        body.classList.remove("medium");
        localStorage.setItem("theme","light");

    }else{
        body.classList.add("dark");
        localStorage.setItem("theme","dark");
    }
}

/* APPLY SAVED THEME ON PAGE LOAD */
window.onload = function(){
    let theme = localStorage.getItem("theme");

    if(theme === "dark"){
        document.body.classList.add("dark");
    }
    else if(theme === "medium"){
        document.body.classList.add("medium");
    }
};
</script>