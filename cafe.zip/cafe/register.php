<?php
session_start();
include "db.php";

$errors  = [];
$success = "";
$name    = "";
$email   = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {

    $name     = trim($_POST['name'] ?$_POST['name']: '');
    $email    = trim($_POST['email'] ?$_POST['email'] : '');
    $password = $_POST['password'] ?$_POST['password']: '';

    // Server-side validation
    if ($name === '') {
        $errors[] = "Full Name is required.";
    } elseif (strlen($name) < 2 || strlen($name) > 100) {
        $errors[] = "Name must be between 2 and 100 characters.";
    }

    if ($email === '') {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if ($password === '') {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (empty($errors)) {
        // Check duplicate email
        $check = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $errors[] = "An account with this email already exists.";
        }
        $check->close();

        if (empty($errors)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $email, $hashedPassword);

            if ($stmt->execute()) {
                $success = "Registered successfully!";
                $name = $email = ""; // Reset fields
            } else {
                $errors[] = "Something went wrong. Please try again.";
                error_log("Registration error: " . $stmt->error);
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
    
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #808080; /* Grey background from image */
            font-family: sans-serif;
        }

        .container {
            display: flex;
            width: 1000px;
            height: 575px;
            background-color: #ffffff; /* White box */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            position: relative;
            border-radius: 20px;
        }

        /* Back button positioned top-left */
        #register.back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            z-index: 1000;
        }

        /* Left Side Image (Updated with Oval Frame & Bottom Fade) */
        .left-side {
            width: 50%;
            background-image: url('https://i.pinimg.com/1200x/20/73/fa/2073fa91485e10340f9b6efb79ad4aa7.jpg'); 
            background-size: cover;
            background-position: center;
            position: relative;
            /* Creates the half-circle on the right side */
            border-top-right-radius: 250px; 
            border-bottom-right-radius: 250px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        
        /* Right Side Form */
        .right-side {
            width: 50%;
            padding: 40px 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-sizing: border-box;
        }

        .right-side h2 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 40px;
            color: #000;
            font-weight: 700;
        }

        .form-group {
            position: relative;
            margin-bottom: 30px;
        }

        /* Left side icons */
        .form-group .field-icon {
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            font-size: 16px;
        }

        .form-group input {
            width: 100%;
            padding: 10px 10px 10px 30px;
            border: none;
            border-bottom: 1px solid #ddd;
            outline: none;
            font-size: 14px;
            background: transparent;
            box-sizing: border-box;
        }

        .form-group input:focus {
            border-bottom: 1px solid #555;
        }

        /* Eye icon positioning - pushed to the far right */
        .form-group .toggle-password {
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            color: #aaa;
            cursor: pointer;
            padding-left: 10px;
        }
        
        /* Adjust password input to accommodate the right-side eye icon */
        .form-group.password-group input {
            padding-right: 30px;
        }

        /* Register Button */
        button[name="register"] {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 30px;
            color: white;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            background: linear-gradient(to right, #2c6e73, #81c784);
            margin-top: 20px;
            margin-bottom: 20px;
        }

        /* Login link */
        .login-link {
            text-align: center;
            font-size: 14px;
            color: #777;
            margin-top: 10px;
        }

        .login-link a {
            color: #000;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            margin-left: 5px;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<!-- Back button top-left -->
<a href="javascript:history.back()" id="register" class="back-btn">&larr; Back</a>

<div class="container">
    <!-- Left Side Image Area -->
    <div class="left-side"></div>

    <!-- Right Side Form Area -->
    <div class="right-side">
        <h2>Register</h2>

        <form method="post">
            
            <div class="form-group">
                <i class="fa-regular fa-user field-icon"></i>
                <input type="text" name="name" required placeholder="Full Name"
                       value="<?php echo htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>">
            </div>

            <div class="form-group">
                <i class="fa-regular fa-envelope field-icon"></i>
                <input type="email" name="email" required placeholder="Email"
                       value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>">
            </div>

            <div class="form-group password-group">
                <i class="fa-solid fa-lock field-icon"></i>
                <input type="password" name="password" id="password" required minlength="6" placeholder="Password">
                <!-- Eye Toggle Button (Far Right) -->
                <i class="fa-regular fa-eye-slash toggle-password" onclick="togglePassword()"></i>
            </div>

            <button name="register" id="register">Register</button>

        </form>

        <!-- Login Link -->
        <div class="login-link">
            Already have an account? 
            <a href="login.php">Log in</a>
        </div>
    </div>
</div>

<!-- JavaScript for Eye Button and Popups -->
<script>
    // Function to toggle password visibility
    function togglePassword() {
        var passwordInput = document.getElementById("password");
        var icon = document.querySelector(".toggle-password");
        
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        } else {
            passwordInput.type = "password";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        }
    }

    // Popup notifications
    <?php if (!empty($errors)): ?>
        alert(<?php echo json_encode(implode("\n", $errors)); ?>);
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        alert(<?php echo json_encode($success); ?>);
        document.querySelector('form').reset();
        // Reset eye icon back to slashed
        document.getElementById("password").type = "password";
        document.querySelector(".toggle-password").classList.remove("fa-eye");
        document.querySelector(".toggle-password").classList.add("fa-eye-slash");
    <?php endif; ?>
</script>

</body>
</html>