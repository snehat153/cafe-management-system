<?php
include "db.php";

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'all';
$price = isset($_GET['price']) ? $_GET['price'] : 'all';

// 1. Build the base query
$sql = "SELECT menu.*, categories.category_name FROM menu 
        JOIN categories ON menu.category_id = categories.id WHERE 1=1";

// 2. Apply Search Filter
if ($search !== '') {
    $searchSafe = $conn->real_escape_string($search);
    $sql .= " AND menu.item_name LIKE '%$searchSafe%'";
}

// 3. Apply Category Filter
if ($category !== 'all') {
    $catSafe = $conn->real_escape_string($category);
    $sql .= " AND menu.category_id = '$catSafe'";
}

// 4. Apply Price Filter
if ($price !== 'all') {
    $priceParts = explode('-', $price);
    if (count($priceParts) == 2) {
        $min = (int)$priceParts[0];
        $max = (int)$priceParts[1];
        $sql .= " AND menu.price >= $min AND menu.price <= $max";
    }
}

// 5. Execute and display
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // We still need to group by category for the layout
    $lastCategory = "";
    
    while($row = $result->fetch_assoc()){
        
        // If a new category starts, close previous grid and open new one
        if ($lastCategory !== $row['category_name']) {
            if ($lastCategory !== "") {
                echo "</div>"; // Close previous grid
            }
            echo "<h2>" . $row['category_name'] . "</h2>";
            echo "<div class='menu-container'>";
            $lastCategory = $row['category_name'];
        }
        ?>
        
        <div class="card">
            <img src="images/<?php echo $row['image']; ?>"><br>
            <h3><?php echo $row['item_name']; ?></h3>
            <p>₹<?php echo $row['price']; ?></p>
            <button onclick="addToCart(<?php echo $row['id']; ?>)">Add to Cart</button>
        </div>

        <?php
    }
    echo "</div>"; // Close the final grid
} else {
    echo "<h3 style='text-align:center; width:100%;'>No items found matching your filters.</h3>";
}
?>