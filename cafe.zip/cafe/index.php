<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>

<?php
include "db.php";
?>
<?php include "navbar.php"; ?>
<h1 style="text-align:center;">Cafe Coffee Care ☕</h1>

<div style="display:grid; grid-template-columns: 1fr 1fr 1fr; ">
    <p><b>Mobile no.: </b>8458847545</p>
    <p><b>Email: </b>cafecoffeecare@gmail.com</p>
    <p><b>Location: </b>45-c, Kanta Chouraha, Jaipur</p>
</div>

<div style="display:flex; align-items:center; justify-content:center;">
<img src="logocafe.png" height="280px" width="280px" style="border-radius:50%; object-fit:cover; box-shadow:0 5px 15px rgba(0,0,0,0.3); border:5px solid #c8a27c;">
</div>