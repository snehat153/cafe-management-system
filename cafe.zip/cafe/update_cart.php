<?php
include "db.php";

session_start();

$user_id = $_SESSION['user_id'];
$item_id = $_GET['id'];
$action = $_GET['action'];

if($action=="plus"){

$conn->query("UPDATE cart 
SET quantity = quantity + 1 
WHERE user_id='$user_id' AND item_id='$item_id'");

}

if($action=="minus"){

$conn->query("UPDATE cart 
SET quantity = quantity - 1 
WHERE user_id='$user_id' AND item_id='$item_id'");

$conn->query("DELETE FROM cart 
WHERE quantity <= 0");

}

header("Location: cart.php");
?>