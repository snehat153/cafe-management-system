<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<?php
include "db.php";

session_start();

$user_id = $_SESSION['user_id'];
$item_id = $_GET['id'];

/* check if item already in cart */

$check = $conn->query("SELECT * FROM cart WHERE user_id='$user_id' AND item_id='$item_id'");

if($check->num_rows > 0){

$conn->query("UPDATE cart 
SET quantity = quantity + 1 
WHERE user_id='$user_id' AND item_id='$item_id'");

}

else{

$conn->query("INSERT INTO cart(user_id,item_id,quantity)
VALUES('$user_id','$item_id',1)");

}

header("Location: cart.php");
?>