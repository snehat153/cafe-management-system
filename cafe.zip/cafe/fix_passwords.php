<?php
// Passwords you want to hash
$passwords = [
    "admin123",
    "sneha123",
    "alex123",
    "max123"
];

echo "<h3>Copy these EXACT hashes into your database:</h3>";

foreach ($passwords as $pwd) {
    $hash = password_hash($pwd, PASSWORD_DEFAULT);
    echo "<strong>Password:</strong> " . $pwd . "<br>";
    echo "<strong>Hash (Length: " . strlen($hash) . "):</strong><br>";
    echo "<textarea rows='2' cols='80'>" . $hash . "</textarea><br><br>";
}
?>