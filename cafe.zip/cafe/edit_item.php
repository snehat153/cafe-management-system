<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

// Check if ID exists
if (!isset($_GET['id'])) {
    echo "<script>alert('No item ID provided.'); window.location.href='dashboard.php';</script>";
    exit();
}

$id = $_GET['id'];

// Fetch current item (with prepared statement)
$stmt_fetch = $conn->prepare("SELECT * FROM menu WHERE id = ?");
$stmt_fetch->bind_param("i", $id);
$stmt_fetch->execute();
$result = $stmt_fetch->get_result();

if ($result->num_rows == 0) {
    echo "<script>alert('Item not found.'); window.location.href='dashboard.php';</script>";
    exit();
}

$row = $result->fetch_assoc();
$stmt_fetch->close();

// Handle Form Submission
$message = "";
$msg_type = "";

if (isset($_POST['update'])) {
    $name = trim($_POST['name']);
    $price = $_POST['price'];
    $category = $_POST['category'];

    $image = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    if ($image != "") {
        // ✅ FIXED PATH: "images/" not "../images/"
        $target_dir = "images/";
        if (!is_dir($target_dir)) { mkdir($target_dir, 0777, true); }

        // Generate unique filename
        $file_extension = pathinfo($image, PATHINFO_EXTENSION);
        $new_filename = time() . "_" . uniqid() . "." . $file_extension;
        $target_file = $target_dir . $new_filename;

        if (move_uploaded_file($tmp, $target_file)) {
            $stmt = $conn->prepare("UPDATE menu SET item_name = ?, price = ?, category_id = ?, image = ? WHERE id = ?");
            $stmt->bind_param("sdisi", $name, $price, $category, $new_filename, $id);
            $stmt->execute();
            $stmt->close();

            echo "<script>
                    alert('Item updated successfully!');
                    window.location.href = 'dashboard.php';
                  </script>";
            exit();
        } else {
            $message = "Failed to upload image. Check folder permissions.";
            $msg_type = "error";
        }
    } else {
        $stmt = $conn->prepare("UPDATE menu SET item_name = ?, price = ?, category_id = ? WHERE id = ?");
        $stmt->bind_param("sdii", $name, $price, $category, $id);
        $stmt->execute();
        $stmt->close();

        echo "<script>
                alert('Item updated successfully!');
                window.location.href = 'dashboard.php';
              </script>";
        exit();
    }

    // Refresh item data in case of error
    $stmt_fetch = $conn->prepare("SELECT * FROM menu WHERE id = ?");
    $stmt_fetch->bind_param("i", $id);
    $stmt_fetch->execute();
    $row = $stmt_fetch->get_result()->fetch_assoc();
    $stmt_fetch->close();
}

// Fetch categories
$categories = $conn->query("SELECT * FROM categories");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu Item - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f0ea;
            margin: 0;
            padding: 0;
            color: #3b2c25;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* BACK BUTTON */
        .back-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #3E2723;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: 0.3s;
        }
        .back-btn:hover { background-color: #241b17; transform: translateY(-2px); }

        /* MAIN CARD */
        .form-card {
            background: #ffffff;
            width: 100%;
            max-width: 500px;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(59, 44, 37, 0.1);
            border-top: 6px solid #6f4e37;
            box-sizing: border-box;
            margin: 60px 20px;
        }

        .form-card h2 {
            text-align: center;
            color: #2c1f1a;
            margin-top: 0;
            margin-bottom: 25px;
            font-size: 24px;
        }

        /* ALERTS */
        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            font-weight: bold;
        }
        .alert-error { background-color: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }

        /* FORM GROUPS */
        .form-group { margin-bottom: 20px; }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 600;
            color: #5a4b45;
        }

        .input-wrapper { position: relative; }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #a89f9a;
            font-size: 16px;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 1px solid #dcdcdc;
            border-radius: 10px;
            font-size: 15px;
            outline: none;
            background-color: #fafafa;
            color: #3b2c25;
            box-sizing: border-box;
            transition: 0.3s;
        }

        .form-group select { cursor: pointer; }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #6a4e42;
            background-color: #fff;
            box-shadow: 0 0 8px rgba(106, 78, 66, 0.2);
        }

        /* CURRENT IMAGE PREVIEW */
        .current-image-box {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: #fafafa;
            border-radius: 10px;
            border: 1px dashed #dcdcdc;
            margin-bottom: 20px;
        }

        .current-image-box img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #6f4e37;
        }

        .current-image-box span {
            color: #5a4b45;
            font-size: 14px;
        }

        /* FILE UPLOAD */
        .file-upload {
            border: 2px dashed #dcdcdc;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            background: #fafafa;
            cursor: pointer;
            transition: 0.3s;
            position: relative;
        }

        .file-upload:hover { border-color: #6f4e37; background: #fff; }

        .file-upload i {
            font-size: 30px;
            color: #6f4e37;
            margin-bottom: 10px;
            display: block;
        }

        .file-upload span { font-size: 14px; color: #777; }

        .file-upload input[type="file"] {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        /* SUBMIT BUTTON */
        .submit-btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            background: linear-gradient(to right, #2c6e73, #81c784);
            transition: 0.3s;
            margin-top: 10px;
        }

        .submit-btn:hover { transform: translateY(-2px); opacity: 0.9; }
    </style>
</head>
<body>

<a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

<div class="form-card">
    <h2>Edit Menu Item</h2>

    <?php if ($message !== ""): ?>
        <div class="alert alert-<?php echo $msg_type; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label>Item Name</label>
            <div class="input-wrapper">
                <i class="fa-solid fa-mug-hot"></i>
                <input type="text" name="name" value="<?php echo htmlspecialchars($row['item_name']); ?>" required>
            </div>
        </div>

        <div class="form-group">
            <label>Price (₹)</label>
            <div class="input-wrapper">
                <i class="fa-solid fa-indian-rupee-sign"></i>
                <input type="number" name="price" value="<?php echo htmlspecialchars($row['price']); ?>" required>
            </div>
        </div>

        <div class="form-group">
            <label>Category</label>
            <div class="input-wrapper">
                <i class="fa-solid fa-layer-group"></i>
                <select name="category" required>
                    <?php
                    while($cat = $categories->fetch_assoc()){
                        $selected = ($cat['id'] == $row['category_id']) ? 'selected' : '';
                        echo "<option value='".$cat['id']."' $selected>".htmlspecialchars($cat['category_name'])."</option>";
                    }
                    ?>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label>Current Image</label>
            <div class="current-image-box">
                <img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="Current Image" onerror="this.src='https://via.placeholder.com/80x80?text=No+Image'">
                <span>This is the current image for this item.</span>
            </div>
        </div>

        <div class="form-group">
            <label>Upload New Image (Optional)</label>
            <div class="file-upload">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                <span>Click to upload or drag & drop<br><small>Leave empty to keep the current image</small></span>
                <input type="file" name="image" accept="image/*">
            </div>
        </div>

        <button type="submit" name="update" class="submit-btn">Update Item</button>

    </form>
</div>

</body>
</html>