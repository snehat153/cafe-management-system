<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
</head>
<?php
include "db.php";
include "navbar.php";

session_start();

$user_id=$_SESSION['user_id'];

$user=$conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();

?>

<h2>Customer Profile</h2>

Name: <?php echo $user['name']; ?><br>

Email: <?php echo $user['email']; ?><br>

<br>

<a href="order_history.php">View Your Orders</a>