<?php
// 1. Start session ONLY if it hasn't been started already
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
include "navbar.php";

// 2. Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Show the "Login First" button instead of plain text
    echo "
    <div style='display: flex; flex-direction: column; justify-content: center; align-items: center; height: 60vh; font-family: sans-serif;'>
        <h2 style='color: #3b2c25; margin-bottom: 10px;'>Login First</h2>
        <p style='color: #777; margin-bottom: 20px;'>You need to be logged in to view your order history.</p>
        <a href='login.php' style='padding: 12px 30px; background-color: #3E2723; color: white; text-decoration: none; border-radius: 25px; font-weight: bold;'>Go to Login</a>
    </div>
    ";
    exit(); 
}

$user_id = $_SESSION['user_id'];

// 3. Fetch orders
$result = $conn->query("SELECT * FROM orders WHERE user_id='$user_id' ORDER BY id DESC");

echo "<div style='padding: 20px; font-family: sans-serif; max-width: 800px; margin: 0 auto;'>";
echo "<h2 style='color: #3b2c25;'>Your Orders</h2>";

if($result->num_rows == 0){
    echo "<p style='text-align:center; color:#777; margin-top:50px;'>No orders found.</p>";
}

while($order = $result->fetch_assoc()){

    echo "<div style='border:1px solid #ddd; padding:15px; margin:15px 0; border-radius:10px; background:#fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);'>";

    echo "<p style='margin: 5px 0;'><b>Order ID:</b> #" . $order['id'] . "</p>";
    echo "<p style='margin: 5px 0;'><b>Total:</b> ₹" . $order['total'] . "</p>";
    echo "<p style='margin: 5px 0;'><b>Status:</b> <span style='color: #2c6e73; font-weight:bold;'>" . $order['status'] . "</span></p>";
    echo "<p style='margin: 5px 0;'><b>Date:</b> " . $order['order_date'] . "</p>";

    echo "<a href='bill.php?order_id=".$order['id']."' style='display:inline-block; margin-top:10px; padding:8px 15px; background:#b2967d; color:white; text-decoration:none; border-radius:5px; font-size:14px;'>View Bill</a>";
    echo "</div>";

}

echo "</div>";
?>