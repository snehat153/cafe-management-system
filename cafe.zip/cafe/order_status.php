<?php
// 1. Start session ONLY if it hasn't been started already
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";
include "navbar.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Show the "Login First" button instead of plain text
    echo "
    <div style='display: flex; flex-direction: column; justify-content: center; align-items: center; height: 60vh; font-family: sans-serif;'>
        <h2 style='color: #3b2c25; margin-bottom: 10px;'>Login First</h2>
        <p style='color: #777; margin-bottom: 20px;'>You need to be logged in to track your orders.</p>
        <a href='login.php' style='padding: 12px 30px; background-color: #3E2723; color: white; text-decoration: none; border-radius: 25px; font-weight: bold;'>Go to Login</a>
    </div>
    ";
    exit(); 
}

$user_id = $_SESSION['user_id'];

// 🔍 search
$search = "";
if(isset($_GET['search'])){
    $search = trim($_GET['search']);
}
?>

<h2 style="text-align:center; color:#3b2c25; margin-top:20px;">Order Tracking</h2>

<!-- 🔍 SEARCH -->
<form method="GET" style="text-align:center; margin:20px;">
    <input type="text" name="search" placeholder="Search by Order ID"
           value="<?php echo htmlspecialchars($search); ?>"
           style="padding:10px; width:250px; border:1px solid #ccc; border-radius:5px; outline:none;">
    <button type="submit" style="padding:10px 20px; background:#3E2723; color:white; border:none; border-radius:5px; cursor:pointer; margin-left:5px;">Search</button>
</form>

<div style="width:70%; margin:auto; font-family:sans-serif; padding-bottom: 50px;">

<?php

// ✅ MAIN QUERY
$query = "SELECT * FROM orders WHERE user_id = '$user_id'";

// 🔍 SEARCH FILTER
if($search != ""){
    $query .= " AND id LIKE '%$search%'";
}

$query .= " ORDER BY id DESC";

$result = $conn->query($query);

if($result && $result->num_rows > 0){

    while($row = $result->fetch_assoc()){

        $status = $row['status'];
        $progress = 0;

        if($status=="Pending") $progress=25;
        if($status=="Preparing") $progress=50;
        if($status=="Ready") $progress=75;
        if($status=="Completed") $progress=100;
        ?>

        <!-- 🔥 ORDER CARD -->
        <div style="border:1px solid #ddd; padding:20px; margin-bottom:20px; border-radius:10px; background:#fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">

            <h3 style="color:#3b2c25; margin-top:0;">Order ID: #<?php echo $row['id']; ?></h3>

            <div style="display:flex; justify-content:space-between; font-weight:bold; color:#777; font-size: 14px;">
                <span>Placed</span>
                <span>Preparing</span>
                <span>Ready</span>
                <span>Completed</span>
            </div>

            <div style="background:#eee; height:20px; border-radius:10px; margin-top:10px; overflow: hidden;">
                <div style="
                    width:<?php echo $progress; ?>%;
                    background: linear-gradient(to right, #f7d794, #f5c16c, #e0a96d);
                    height:20px;
                    border-radius:10px;
                    transition: width 1s ease-in-out;
                    box-shadow: 0 0 8px rgba(255,215,0,0.5);
                ">
                </div>
            </div>

            <p style="margin-top:15px; font-size: 16px;">
                Current Status: <b style="color: #3b2c25;"><?php echo $status; ?></b>
            </p>

        </div>

        <?php
    }

} else {
    echo "<p style='text-align:center; color:#777;'>No Orders Found</p>";
}
?>

</div>