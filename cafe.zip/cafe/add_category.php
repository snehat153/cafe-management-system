<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

$message = "";
$msg_type = "";

// Handle Form Submission
if (isset($_POST['add_category'])) {
    $cat_name = trim($_POST['category_name']);
    
    if ($cat_name === '') {
        $message = "Category name cannot be empty.";
        $msg_type = "error";
    } else {
        // Check if category already exists
        $check = $conn->prepare("SELECT id FROM categories WHERE category_name = ?");
        $check->bind_param("s", $cat_name);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $message = "This category already exists.";
            $msg_type = "error";
        } else {
            $stmt = $conn->prepare("INSERT INTO categories (category_name) VALUES (?)");
            $stmt->bind_param("s", $cat_name);
            if ($stmt->execute()) {
                $message = "Category added successfully!";
                $msg_type = "success";
                $cat_name = ""; // Reset input
            } else {
                $message = "Error adding category.";
                $msg_type = "error";
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category - Cafe Coffee Care</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f0ea;
            margin: 0;
            padding: 0;
            color: #3b2c25;
        }

        /* BACK BUTTON */
        .back-btn {
            position: fixed;
            top: 20px;
            left: 20px;
            padding: 10px 20px;
            background-color: #3E2723;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: 0.3s;
            z-index: 1000;
        }
        .back-btn:hover { background-color: #241b17; transform: translateY(-2px); }

        /* MAIN CONTAINER */
        .container {
            max-width: 700px;
            margin: 100px auto 40px auto; /* Top margin to clear back button */
            padding: 0 20px;
        }

        .form-card {
            background: #ffffff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(59, 44, 37, 0.1);
            border-top: 6px solid #6f4e37;
        }

        .form-card h2 {
            text-align: center;
            color: #2c1f1a;
            margin-top: 0;
            margin-bottom: 30px;
        }

        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
            font-weight: bold;
        }
        .alert-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
        .alert-error { background: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }

        .input-group {
            display: flex;
            gap: 10px;
            margin-bottom: 40px;
        }

        .input-group input {
            flex: 1;
            padding: 15px;
            border: 1px solid #dcdcdc;
            border-radius: 10px;
            font-size: 15px;
            outline: none;
            background-color: #fafafa;
            transition: 0.3s;
        }

        .input-group input:focus {
            border-color: #6f4e37;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(111, 78, 55, 0.2);
        }

        .input-group button {
            padding: 15px 25px;
            background: #2c6e73;
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            font-size: 15px;
            cursor: pointer;
            transition: 0.3s;
        }
        .input-group button:hover { background: #1f4f53; transform: translateY(-2px); }

        /* CATEGORY LIST TABLE */
        h3 { color: #5a4b45; margin-bottom: 15px; }
        
        .cat-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .cat-table th, .cat-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .cat-table th {
            background: #f4f0ea;
            color: #5a4b45;
            font-weight: 600;
        }

        .cat-table tr:hover { background: #fafafa; }

        .delete-cat-btn {
            color: #c62828;
            text-decoration: none;
            font-weight: bold;
            font-size: 13px;
        }
        .delete-cat-btn:hover { text-decoration: underline; }
    </style>
</head>
<body>

<!-- Back Button -->
<a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

<div class="container">
    <div class="form-card">
        <h2>Add New Category</h2>
        
        <?php if ($message !== ""): ?>
            <div class="alert alert-<?php echo $msg_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="post" class="input-group">
            <input type="text" name="category_name" placeholder="Enter category name (e.g. Cold Coffee)" required>
            <button type="submit" name="add_category">Add Category</button>
        </form>

        <h3>Existing Categories</h3>
        <table class="cat-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Category Name</th>
                    <th style="text-align:right;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $cat_list = $conn->query("SELECT * FROM categories ORDER BY id ASC");
                if ($cat_list->num_rows > 0) {
                    while($c = $cat_list->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>#".$c['id']."</td>";
                        echo "<td>".htmlspecialchars($c['category_name'])."</td>";
                        echo "<td style='text-align:right;'><a href='delete_category.php?id=".$c['id']."' class='delete-cat-btn' onclick=\"return confirm('Are you sure you want to delete this category?');\">Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3' style='text-align:center; color:#777;'>No categories found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>