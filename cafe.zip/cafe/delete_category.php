<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "db.php";

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: add_category.php");
    exit();
}

$id = $_GET['id'];

// Use prepared statement to delete securely
$stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "<script>
            alert('Category deleted successfully.');
            window.location.href = 'add_category.php';
          </script>";
} else {
    echo "<script>
            alert('Error deleting category. It might be linked to menu items.');
            window.location.href = 'add_category.php';
          </script>";
}

$stmt->close();
?>